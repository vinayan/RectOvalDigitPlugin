# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from ui_CADDigitizeSettings import Ui_CADDigitizeSettings
import os, sys

class CADDigitizeSettingsGui(QDialog, Ui_CADDigitizeSettings):

    # btnSelectVertex_clicked = pyqtSignal()

    def __init__(self, parent):
        QDialog.__init__(self, parent)
        self.setupUi(self)
    
        self.settings = QSettings()
        self.circleSegmentsSpinbox = self.settings.value("/CADDigitize/circle/segments", 36,type=int)
        self.ellipsePointsSpinbox = self.settings.value("/CADDigitize/ellipse/segments", 36,type=int)
        self.ArcFeaturePitch = self.settings.value("/CADDigitize/arc/pitch", 2,type=int)
        self.ArcFeatureAngle = self.settings.value("/CADDigitize/arc/angle", 1,type=int)
        self.featureMethod = self.settings.value("/CADDigitize/arc/method",  "pitch")
        self.angleDirection = self.settings.value("/CADDigitize/arc/direction",  "ClockWise")

        if self.featureMethod == "pitch":
            self.radioFeaturePitch.setChecked(True)
            self.radioFeatureAngle.setChecked(False)
        else:
            self.radioFeaturePitch.setChecked(False)
            self.radioFeatureAngle.setChecked(True) 
            
        if self.angleDirection == "ClockWise":
            self.ArcClockWise.setChecked(True)
            self.ArcCounterClockWise.setChecked(False)
        else:
            self.ArcClockWise.setChecked(False)
            self.ArcCounterClockWise.setChecked(True)
                
        self.okButton = self.buttonBox.button(QDialogButtonBox.Ok)
        self.okButton.clicked.connect(self.accept)

        self.cancelButton = self.buttonBox.button(QDialogButtonBox.Cancel)
        self.cancelButton.clicked.connect(self.close)

        pass



#    @pyqtSignature("on_btnSelectVertex_clicked()") 
#    def on_btnSelectVertex_clicked(self):
#        self.method = "vertex"
#        self.buttonBox.button(QDialogButtonBox.Ok).setEnabled(True)   
#        self.btnSelectVertex_clicked.emit()
#
#
    def accept(self):
        self.setValue("/CADDigitize/circle/segments", self.circleSegmentsSpinbox.value())
        self.setValue("/CADDigitize/ellipse/segments", self.ellipsePointsSpinbox.value())
        self.setValue("/CADDigitize/arc/pitch", self.ArcFeaturePitch.value())
        self.setValue("/CADDigitize/arc/angle", self.ArcFeatureAngle.value())
        
        if self.radioFeaturePitch.isChecked():
            self.setValue("/CADDigitize/arc/method",  "pitch")
        else:
            self.setValue("/CADDigitize/arc/method",  "angle")

        if self.ArcClockWise.isChecked():
            self.setValue("/CADDigitize/arc/direction",  "ClockWise")
        else:
            self.setValue("/CADDigitize/arc/direction",  "CounterClockWise")
            
        self.close()
        
