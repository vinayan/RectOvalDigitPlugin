#-*- coding:utf-8 -*-
from qgis.core import *
from calc import *
from math import *


